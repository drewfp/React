import React from 'react'
import { Button, Checkbox, Form } from 'semantic-ui-react'


const FormExampleForm = () => (
  <Form className="create-form">
    <Form.Field>
      <label>Informe o nome:</label>
      <input placeholder='Primeiro Nome' />
    </Form.Field>
    <Form.Field>
      <label>Informe o Sobrenome</label>
      <input placeholder='Ultimo Nome' />
    </Form.Field>
    <Form.Field>
      <label>Informe a senha </label>
      <input placeholder='Ultimo Nome' />
    </Form.Field>
    <Form.Field>
      <Checkbox label='Eu aceito os termos e condições ' />
    </Form.Field>
    <Button type='submit'>Enviar</Button>
  </Form>
)

export default FormExampleForm